const mongoose = require('mongoose');
 
//Attributes of the Course object
var courseSchema = new mongoose.Schema({
facultyName: {
type: String,
required: 'This field is required!'
},
facultyId: {
type: String
},
ExamHall: {
type: String
},
ExamDate: {
type: Date
}
});
 
mongoose.model('examduty', courseSchema);